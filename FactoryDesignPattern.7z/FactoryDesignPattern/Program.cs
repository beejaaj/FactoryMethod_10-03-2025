﻿// See https://aka.ms/new-console-template for more information
using FactoryDesignPattern;

//var terrestre = new Terrestre();
//var maritmo = new Maritmo();
//terrestre.Transportar();
//maritmo.Transportar();

TransporteFactory terrestreCreator = new TerrestreCreator();
TransporteFactory maritmoCreator = new MaritmoCreator();
Cliente clienteTerrestre = new Cliente(terrestreCreator);
Cliente clienteMaritmo = new Cliente(maritmoCreator);
clienteTerrestre.Transportar("caixas de cerveja");
clienteMaritmo.Transportar("caixas de carro");